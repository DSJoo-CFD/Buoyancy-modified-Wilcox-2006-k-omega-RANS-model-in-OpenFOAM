

clc
clear



close all

clip=1;


folder='700000';  Ra=10^11; Pr=6;  grid_growth=500;  
g=1; 
j=log10(Ra)-4; 
alpha=10^(-1-j/5);
nu=(Pr)*alpha;
beta=(Ra)*nu*alpha;
xmax=1.0;


% xmax=0.2;

file_ku=fopen([folder, '\k'],'r');
file_eu=fopen([folder, '\epsilon'],'r');
file_kt=fopen([folder, '\Tvar'],'r');
file_thf=fopen([folder, '\thf'],'r');
file_T=fopen([folder, '\T'],'r');
ku=cell2mat(textscan(file_ku,'%f','HeaderLines',23))';
eu=cell2mat(textscan(file_eu,'%f','HeaderLines',23))';
kt=cell2mat(textscan(file_kt,'%f','HeaderLines',23))'/2;
T=cell2mat(textscan(file_T,'%f','HeaderLines',23))';
[m,nlist]=size(ku);
grid_n=nlist;
for i=1:23
    tline = fgetl(file_thf);
end
thf=zeros(nlist,1);
for i=1:nlist
    tline = fgetl(file_thf);
    [n,m]=size(tline);
    thf(i)=str2double(tline(4:m-3));
end
fclose(file_ku);
fclose(file_eu);
fclose(file_kt);
fclose(file_thf);
fclose(file_T);
if (grid_growth>1.000001)
    y_min=0.5*(power(grid_growth,(1)/(grid_n/2-1))-1)/(power(grid_growth,(grid_n/2)/(grid_n/2-1))-1);
    growthrate=power(grid_growth,1/(grid_n/2-1));
    size_list=y_min*(growthrate.^(0:(grid_n/2-1)));
    y_list=y_min*(growthrate.^(1:(grid_n/2))-1)/(growthrate-1);
    y_list2=1-y_list(grid_n/2-1:-1:1);
    yy=([0, y_list, y_list2] + [y_list, y_list2, 1])/2;
    yy_size=[size_list, size_list(grid_n/2:-1:1)];
else
    yy=((1:grid_n)-0.5)/grid_n;
    y_list=(1:(grid_n/2))/grid_n;
    y_list2=1-y_list(grid_n/2-1:-1:1);
    yy_size=ones(1,grid_n)*1/grid_n;
end


yy_face=[y_list, y_list2];
T_face=(T(2:grid_n)-T(1:grid_n-1))./(yy(2:grid_n)-yy(1:grid_n-1)).*(yy_face-yy(1:grid_n-1))+T(1:grid_n-1);
T_face=[1, T_face, 0];
yy_face=[0, yy_face, 1];
dTdy=(T_face(2:grid_n+1)-T_face(1:grid_n))./(yy_face(2:grid_n+1)-yy_face(1:grid_n));

yy_face=[y_list, y_list2];
k_face=(ku(2:grid_n)-ku(1:grid_n-1))./(yy(2:grid_n)-yy(1:grid_n-1)).*(yy_face-yy(1:grid_n-1))+ku(1:grid_n-1);
k_face=[1, k_face, 0];
yy_face=[0, yy_face, 1];
dkdy=(k_face(2:grid_n+1)-k_face(1:grid_n))./(yy_face(2:grid_n+1)-yy_face(1:grid_n));

yy_face=[y_list, y_list2];
dkdy_face=(dkdy(2:grid_n)-dkdy(1:grid_n-1))./(yy(2:grid_n)-yy(1:grid_n-1)).*(yy_face-yy(1:grid_n-1))+dkdy(1:grid_n-1);
dkdy_face=[1, dkdy_face, 0];
yy_face=[0, yy_face, 1];
dkdy2=(dkdy_face(2:grid_n+1)-dkdy_face(1:grid_n))./(yy_face(2:grid_n+1)-yy_face(1:grid_n));
dkdy2(1:3)=zeros(1,3);

ku2=sqrt(ku);
kt2=sqrt(kt);

yy_face=[y_list, y_list2];
ku2_face=(ku2(2:grid_n)-ku2(1:grid_n-1))./(yy(2:grid_n)-yy(1:grid_n-1)).*(yy_face-yy(1:grid_n-1))+ku2(1:grid_n-1);
ku2_face=[0, ku2_face, 0];
yy_face=[0 yy_face, 1];
dku2dy=(ku2_face(2:grid_n+1)-ku2_face(1:grid_n))./(yy_face(2:grid_n+1)-yy_face(1:grid_n));

yy_face=[y_list, y_list2];
kt2_face=(kt2(2:grid_n)-kt2(1:grid_n-1))./(yy(2:grid_n)-yy(1:grid_n-1)).*(yy_face-yy(1:grid_n-1))+kt2(1:grid_n-1);
kt2_face=[0, kt2_face, 0];
yy_face=[0 yy_face, 1];
dkt2dy=(kt2_face(2:grid_n+1)-kt2_face(1:grid_n))./(yy_face(2:grid_n+1)-yy_face(1:grid_n));

eu_vis=2*nu*(dku2dy.*dku2dy);
et_vis=2*nu/Pr*(dkt2dy.*dkt2dy);

et=2*eu.*kt./ku;

thf_avg=sum(thf'.*yy_size);
ku_avg=sum(ku.*yy_size);
kt_avg=sum(kt.*yy_size);
eu_avg=sum(eu.*yy_size);
eu_vis_avg=sum(eu_vis.*yy_size);
et_avg=sum(et.*yy_size);
et_vis_avg=sum(et_vis.*yy_size);


fprintf('%d\n',thf(grid_n/2));
fprintf('%d\n',ku(grid_n/2));
fprintf('%d\n',eu(grid_n/2));
fprintf('%d\n',kt(grid_n/2));
fprintf('%d\n\n',et(grid_n/2));

fprintf('%d\n',ku_avg);
fprintf('%d\n',kt_avg);
fprintf('%d\n',eu_avg);
fprintf('%d\n',eu_vis_avg);
fprintf('%d\n',et_avg);
fprintf('%d\n',et_vis_avg);

dTdy(1:clip)=0;

nondimen=1;
alphat=0.2*ku.*ku./eu;
plot(yy,-(dTdy.*alpha)*nondimen,'.',yy,(thf'-dTdy.*alphat)*nondimen,'.',yy,(thf'-dTdy.*alphat-dTdy*alpha)*nondimen);
legend('dTdy','thf','total')
xlim([0 xmax]);
exportgraphics(gcf,'heat balance.png','Resolution',300)

plot(yy,eu,'.')
xlim([0 xmax]);
exportgraphics(gcf,'epsilon.png','Resolution',300)

plot(yy,ku,'.')
xlim([0 xmax]);
exportgraphics(gcf,'k.png','Resolution',300)

plot(yy,kt,'.')
xlim([0 xmax]);
exportgraphics(gcf,'Tvar.png','Resolution',300)
% 
nut=0.09*ku.*ku./eu;
plot(yy,g*beta*thf,yy,eu,yy,(nu+nut).*dkdy2)
legend('PG','epsilon')
xlim([0 xmax]);
title('k budget')

plot(yy,nut)
xlim([0 xmax]);
title('nut')
exportgraphics(gcf,'nut.png','Resolution',300)

plot(yy,T)
xlim([0 xmax]);
title('T')
exportgraphics(gcf,'T.png','Resolution',300)


max(T)
sum(dTdy(2:3))/2
sum(dTdy(nlist-3:nlist))/4