clc
clear
% 가장 윗 폴더에서 실행

% alpha=zeros(9,8);
% nu=zeros(9,8);
% beta=zeros(9,8);

% Q=alpha;



% for Pr=-2:0.5:3
cfl=[];
Ret=[];
for Pr=log10(6)
    i=Pr*2+5;
    for Ra=5:12   
        j=Ra-4; 
        alpha=10^(-1-j/2);
        % alpha=0.001/(10^(Ra/2));
        nu=(10^Pr)*alpha;
        beta=(10^Ra)*nu*alpha;
        text = 'sed -i "20s/.*/nu '+string(nu)+';/g" Ra' + string(Ra) + '/constant/transportProperties';
        disp(text)
        text = 'sed -i "23s/.*/beta '+string(beta)+';/g" Ra' + string(Ra) + '/constant/transportProperties';
        disp(text)
        text = 'sed -i "29s/.*/Pr '+string(10^Pr)+';/g" Ra' + string(Ra) + '/constant/transportProperties';
        disp(text)
        
        text = 'sed -i "32s/.*/Q '+string(alpha)+';/g" Ra' + string(Ra) + '/constant/transportProperties';
        disp(text)

        g=1;
        % g*beta*k*k*0.15*nu*nu*10000=k^2;
        k=sqrt(g*beta)*nu*100;
        epsilon=k^2/nu/100;
        Tvar=0.15*k*k/epsilon/g/beta;
        Ret=[Ret k*k/epsilon/nu];

        text = 'sed -i "19s/.*/internalField uniform '+string(k)+';/g" Ra' + string(Ra) + '/0.orig/k';
        disp(text)
        text = 'sed -i "19s/.*/internalField uniform '+string(Tvar)+';/g" Ra' + string(Ra) + '/0.orig/Tvar';
        disp(text)
        text = 'sed -i "19s/.*/internalField uniform '+string(epsilon)+';/g" Ra' + string(Ra) + '/0.orig/epsilon';
        disp(text)
        % cfl=[cfl 1/500/sqrt(g*beta)];
    end
end

% alpha=const
% 
% 0.001=Ra*nu =const



Ra=log10(beta./nu./alpha);
Pr=log10(nu./alpha);

disp('find ./ -name "g" -exec sed -i "18s/.*/value (0 -1 0);/g" {} \;')
disp('find ./ -name "controlDict" -exec sed -i "25s/.*/endTime 100000;/g"  {} \;')

% sed -i "행번호s/.*/새문자열/g" 파일명
