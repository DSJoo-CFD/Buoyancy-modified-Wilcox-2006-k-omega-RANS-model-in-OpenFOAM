clc
clear
close all;

Tmax=[];
Tavg=[];
Fup=[];
Fdn=[];

for i_Ra=5:12
    if i_Ra==5
        folder='Ra5/300000';  Ra=10^5; Pr=0;  grid_growth=50;
    elseif i_Ra==6
        folder='Ra6/300000';  Ra=10^6; Pr=0;  grid_growth=100;
    elseif i_Ra==7
        folder='Ra7/300000';  Ra=10^7; Pr=0;  grid_growth=100;
    elseif i_Ra==8
        folder='Ra8/300000';  Ra=10^8; Pr=0;  grid_growth=200;
    elseif i_Ra==9
        folder='Ra9/300000';  Ra=10^9; Pr=0;  grid_growth=200;
    elseif i_Ra==10
        folder='Ra10/300000';  Ra=10^10; Pr=0;  grid_growth=200;
    elseif i_Ra==11
        folder='Ra11/300000';  Ra=10^11; Pr=0;  grid_growth=200;
    elseif i_Ra==12
        folder='Ra12/300000';  Ra=10^12; Pr=0;  grid_growth=200;
    end
   
    g=1; j=log10(Ra)-4; alpha=10^(-1-j/5);nu=(Pr)*alpha;beta=(Ra)*nu*alpha; xmax=1.0;
    file_T=fopen([folder, '\T'],'r');
    T=cell2mat(textscan(file_T,'%f','HeaderLines',23))';
    [m,nlist]=size(T);
%     grid_n=nlist;
%     if (grid_growth>1.000001)
%         y_min=0.5*(power(grid_growth,(1)/(grid_n/2-1))-1)/(power(grid_growth,(grid_n/2)/(grid_n/2-1))-1);
%         growthrate=power(grid_growth,1/(grid_n/2-1));
%         size_list=y_min*(growthrate.^(0:(grid_n/2-1)));
%         y_list=y_min*(growthrate.^(1:(grid_n/2))-1)/(growthrate-1);
%         y_list2=1-y_list(grid_n/2-1:-1:1);
%         yy=([0, y_list, y_list2] + [y_list, y_list2, 1])/2;
%         yy_size=[size_list, size_list(grid_n/2:-1:1)];
%     else
%         yy=((1:grid_n)-0.5)/grid_n;
%         y_list=(1:(grid_n/2))/grid_n;
%         y_list2=1-y_list(grid_n/2-1:-1:1);
%         yy_size=ones(1,grid_n)*1/grid_n;
%     end
% 
%     yy_face=[y_list, y_list2];
%     T_face=(T(2:grid_n)-T(1:grid_n-1))./(yy(2:grid_n)-yy(1:grid_n-1)).*(yy_face-yy(1:grid_n-1))+T(1:grid_n-1);
%     T_face=[1, T_face, 0];
%     yy_face=[0, yy_face, 1];
%     dTdy=(T_face(2:grid_n+1)-T_face(1:grid_n))./(yy_face(2:grid_n+1)-yy_face(1:grid_n));
% 
    Tmax=[Tmax, max(T)];
    % Tavg=[Tavg, sum((yy(2:nlist)-yy(1:nlist-1)).*(T(2:nlist)+T(1:nlist-1))/2)];
% 
% 
%     Fdn=[Fdn, sum(dTdy(2:4))/3];
%     Fup=[Fup, sum(dTdy(nlist-3:nlist-1))/3];
% 
% 
%     if i_Ra==5
%         yy5=yy; T5=T;
%     elseif i_Ra==6
%         yy6=yy; T6=T;
%     elseif i_Ra==7
%         yy7=yy; T7=T;
%     elseif i_Ra==8
%         yy8=yy; T8=T;
%     elseif i_Ra==9
%         yy9=yy; T9=T;
%     elseif i_Ra==10
%         yy10=yy; T10=T;
%     elseif i_Ra==11
%         yy11=yy; T11=T;
%     elseif i_Ra==12
%         yy12=yy; T12=T;
%     end
end
% 
% plot(T5,yy5, ...
%     T6,yy6, ...
%     T7,yy7, ...
%     T8,yy8, ...
%     T9,yy9)
% 
% 
% xlabel("$T^\ast$","interpreter","latex")
% ylabel("$z/L$","interpreter","latex")
% grid on
% % xlim([0 0.13])
% 
% set(gcf, 'Color', 'w');
% set(gcf, 'Position',  [500, 500, 330, 280]);
% set(gca,'FontSize',10,'fontname','Times New Roman')
% 
% 
% exportgraphics(gcf,'IHC1_temperature.png','Resolution',450)
% 
% dTdy(2:4)
% dTdy(nlist-3:nlist-1)
% disp(Tmax')
% disp(Tavg')
% disp(Fup')
% disp(Fdn')
% 
% disp(Fdn'-Fup')
% % plot(yy12,T12,'.')