#!/bin/bash

MAX_PARALLEL=8

FOLDERS=*/

run_in_folder() {
    local d="$1"
    echo ">>> Running in: $d"
    cd "$d" || exit
    sh ./Allclean }

export -f run_in_folder

printf "%s\n" $FOLDERS | xargs -I{} -P "$MAX_PARALLEL" bash -lc 'run_in_folder "{}"'

echo "== 모든 작업 완료 =="
